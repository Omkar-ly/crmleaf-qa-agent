import os
import sys
import time
from datetime import datetime
from playwright.sync_api import sync_playwright
from core.context import RunContext
from core.models import Finding
from detectors.observer import DOMAndNetworkObserver
from evidence.collector import EvidenceCollector
from storage.excel_sink import ExcelTicketSink

from modules.psa.m01_lead import LeadCreationModule
from modules.psa.m02_proposal import ProposalModule
from modules.psa.m03_contract import ContractModule
from modules.psa.m04_project import ProjectCreationModule
from modules.psa.m05_overview import ProjectOverviewModule
from modules.psa.m06_files import ProjectFilesModule
from modules.psa.m07_milestones import MilestonesModule
from modules.psa.m08_tasks import TasksModule
from modules.psa.m09_task_board import TaskBoardModule
from modules.psa.m10_gantt import GanttChartModule
from modules.psa.m11_invoices import InvoicesModule


class AutonomousEngine:
    def __init__(self, email: str, password: str):
        self.email = email
        self.password = password
        self.sink = ExcelTicketSink("PSA_Defect_Store.xlsx")
        self.pipeline = [
            LeadCreationModule(),
            ProposalModule(),
            ContractModule(),
            ProjectCreationModule(),
            ProjectOverviewModule(),
            ProjectFilesModule(),
            MilestonesModule(),
            TasksModule(),
            TaskBoardModule(),
            GanttChartModule(),
            InvoicesModule(),
        ]

    def _login(self, page, base_url):
        page.goto(f"{base_url}/login")
        page.get_by_role("textbox", name="Email Address").fill(self.email)
        page.get_by_role("textbox", name="Password").fill(self.password)
        page.get_by_role("button", name="Log In").click()
        page.wait_for_load_state("networkidle")

        # Handle the workspace / company selection if present
        company_link = page.get_by_role("link", name="BDM Industries")
        if company_link.is_visible(timeout=5000):
            try:
                company_link.click(timeout=3000)
                page.wait_for_load_state("networkidle")
            except Exception:
                # If unclickable or blocked by overlay, navigate directly to dashboard
                page.goto(f"{base_url}/account/dashboard")
                page.wait_for_load_state("networkidle")
        else:
            # Already redirected into the workspace
            page.goto(f"{base_url}/account/dashboard")
            page.wait_for_load_state("networkidle")

    def run(self):
        run_id = f"RUN_{datetime.now().strftime('%Y%m%d_%H%M%S')}"
        ctx = RunContext(run_id=run_id)
        evidence = EvidenceCollector(run_id=run_id)

        passed_count = 0
        failed_count = 0
        blocked_count = 0
        is_blocked = False

        with sync_playwright() as p:
            browser = p.chromium.launch(headless=False)
            context = browser.new_context(
                record_video_dir=f"evidence/{run_id}/recordings",
                viewport={"width": 1920, "height": 1080},
            )
            context.tracing.start(screenshots=True, snapshots=True, sources=True)
            page = context.new_page()
            observer = DOMAndNetworkObserver(page)

            print(f"[*] Starting Autonomous Engine Run: {run_id}")
            self._login(page, ctx.base_url)

            for module in self.pipeline:
                if is_blocked:
                    print(f"[-] [BLOCKED] {module.name} (Upstream dependency failed)")
                    blocked_count += 1
                    continue

                observer.clear()
                print(f"[>] Executing: {module.name}...")

                success = False
                last_error = ""

                for attempt in range(1, 3):
                    try:
                        module.execute(page, ctx)
                        success = True
                        break
                    except Exception as ex:
                        last_error = str(ex)
                        time.sleep(2)

                if success:
                    print(f"[+] [PASS] {module.name}")
                    passed_count += 1
                else:
                    print(f"[!] [FAIL] {module.name} (Attempt {attempt}): {last_error}")
                    failed_count += 1
                    is_blocked = True

                    ss_path = evidence.capture_screenshot(
                        page, module.name.replace(" ", "_")
                    )
                    vid_path = evidence.get_video_path(
                        page, module.name.replace(" ", "_")
                    )

                    finding = Finding(
                        module="PSA",
                        screen=module.name,
                        failure_type="AssertionOrDOMError",
                        severity="Critical",
                        title=f"Autonomous Check Failure in {module.name}",
                        repro_steps=f"Automated execution broke during {module.name} pipeline stage.",
                        expected=f"Module {module.name} completes successfully without exceptions.",
                        actual=last_error,
                        error_message=last_error,
                        screenshot_path=ss_path,
                        video_path=vid_path,
                    )
                    self.sink.sync_finding(finding, run_id)

            context.tracing.stop(path=f"evidence/{run_id}/trace.zip")
            context.close()
            browser.close()

        self.sink.log_run(
            run_id, len(self.pipeline), passed_count, failed_count, blocked_count
        )
        print(
            f"[*] Run Complete: {passed_count} Passed, {failed_count} Failed, {blocked_count} Blocked."
        )
        print("[*] Report & Evidence recorded to PSA_Defect_Store.xlsx")


if __name__ == "__main__":
    email = os.environ.get("CRMLeaf_USERNAME")
    password = os.environ.get("CRMLeaf_PASSWORD")

    if not email or not password:
        print(
            "[!] Missing credentials. Please set environment variables before running:"
        )
        print('    $env:CRMLeaf_USERNAME="your_email@domain.com"')
        print('    $env:CRMLeaf_PASSWORD="your_password"')
        sys.exit(1)

    engine = AutonomousEngine(email=email, password=password)
    engine.run()
