from pathlib import Path
from typing import Optional
from playwright.sync_api import Page


class EvidenceCollector:
    def __init__(self, run_id: str, base_dir: str = "evidence"):
        self.run_id = run_id
        self.base_dir = Path(base_dir) / run_id
        self.base_dir.mkdir(parents=True, exist_ok=True)

    def capture_screenshot(self, page: Page, screen_name: str) -> str:
        screen_dir = self.base_dir / screen_name
        screen_dir.mkdir(parents=True, exist_ok=True)
        file_path = screen_dir / f"{screen_name}_failure.png"
        page.screenshot(path=str(file_path), full_page=True)
        return str(file_path)

    def get_video_path(self, page: Page, screen_name: str) -> Optional[str]:
        video = page.video
        if video:
            try:
                # video.path() retrieves the path of the recording file
                raw_path = video.path()
                return str(raw_path)
            except Exception:
                return None
        return None
