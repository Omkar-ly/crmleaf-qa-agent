from playwright.sync_api import Page, expect
from core.base_module import ScreenModule
from core.context import RunContext


class LeadCreationModule(ScreenModule):
    name = "Lead Creation"

    def execute(self, page: Page, ctx: RunContext) -> None:
        lead_name = f"ASO_{ctx.run_id[-4:]}"
        ctx.lead_name = lead_name
        ctx.lead_email = f"lead_{ctx.run_id[-4:]}@example.com"
        ctx.company_name = f"Company_{ctx.run_id[-4:]}"

        page.goto(f"{ctx.base_url}/account/lead-contact")
        page.wait_for_load_state("networkidle")

        page.get_by_role("link", name="Add Lead Contact").click()
        page.wait_for_selector("#save-lead-data-form", timeout=10000)

        # Salutation dropdown
        page.get_by_role("combobox", name="--").first.click()
        page.locator("#bs-select-8-1").click()

        # Basic details
        page.get_by_role("textbox", name="Name *", exact=True).fill(ctx.lead_name)
        page.get_by_role("textbox", name="Email").fill(ctx.lead_email)

        # Add Company button (robust fallback matching icon/button/link)
        add_company_btn = (
            page.locator("button:has-text('Add'), a:has-text('Add')")
            .filter(has=page.locator(".fa-plus, i, svg"))
            .first
        )
        if add_company_btn.is_visible(timeout=3000):
            add_company_btn.click()
        else:
            page.locator(
                ".add-lead-company, [data-target='#addLeadCompanyModal']"
            ).first.click()

        page.wait_for_selector("#save-lead-company", timeout=7000)
        page.get_by_role("textbox", name="Company Name *").fill(ctx.company_name)
        page.locator("#save-lead-company").click()

        # Wait for company modal to dismiss
        page.wait_for_selector("#save-lead-company", state="hidden", timeout=7000)

        # Uncheck Create Deal to keep Lead pure
        deal_box = page.get_by_role("checkbox", name="Create Deal")
        if deal_box.is_checked():
            deal_box.uncheck()

        page.get_by_role("button", name="Save", exact=True).click()

        # Verify Contact is present in grid
        expect(page.locator("body")).to_contain_text(ctx.lead_name, timeout=10000)
