import re
from playwright.sync_api import Page, expect
from core.base_module import ScreenModule
from core.context import RunContext


class ProposalModule(ScreenModule):
    name = "Proposal Creation & Acceptance"

    def execute(self, page: Page, ctx: RunContext) -> None:
        page.goto(f"{ctx.base_url}/account/proposals")
        page.get_by_role("link", name="Create Proposal").click()

        page.get_by_role("combobox", name="--").first.click()
        page.locator(".dropdown-menu.show").get_by_text(ctx.lead_name).first.click()

        page.get_by_role("textbox", name="Item Name").fill("Smart Watch")
        page.get_by_role("row", name="Sub Total").click()

        page.get_by_role("spinbutton", name="0", exact=True).fill("10")

        page.get_by_role("button", name="Save").click()
        page.get_by_role("link", name="Save & Send").click()

        page.goto(f"{ctx.base_url}/account/proposals")
        first_row_menu = page.locator("[id^=dropdownMenuLink-]").first
        first_row_menu.click()

        with page.expect_popup() as popup_info:
            page.get_by_role("link", name="Public Link").click()
        public_page = popup_info.value

        public_page.get_by_role("link", name="Accept").click()
        public_page.get_by_role("textbox", name="Name *").fill(ctx.lead_name)
        public_page.get_by_role("textbox", name="Email *").fill(ctx.lead_email)
        public_page.locator("#signature-pad").click(position={"x": 200, "y": 50})
        public_page.get_by_role("button", name="Sign", exact=True).click()
        public_page.close()
